<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Joabeman</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="Our site is coming soon. A new generation of something. Created by JohnAbeMan." />
	<meta name="keywords" content="Joabeman,johnabelardo,abelardomanangan,john abelardo" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.1.35" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1469326523" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1469326523" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="/gallery/question-mark-ts1469323908.png" type="image/png" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div id="wb_bgs_cont"><div id="wb_page_1_bg"></div></div><div id="wb_header_bg"></div><div id="wb_sbg_placeholder"></div><div class="vbox wb_container wb_header_fixed" id="wb_header">
	
<div id="wb_element_instance0" class="wb_element"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu menu-landing"></ul><script type="text/javascript"> (function() { var isOpen = false, elem = $('#wb_element_instance0'), btn = elem.children('.btn-collapser').eq(0); btn.on('click', function() { if (elem.hasClass('collapse-expanded')) { isOpen = false; elem.removeClass('collapse-expanded'); } else { isOpen = true; elem.addClass('collapse-expanded'); } }); })(); </script></div><div id="wb_element_instance3" class="wb_element"><div></div></div><div id="wb_element_instance4" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Joabeman</h1>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_page" id="page_1"><a name="jimbo-pe-hu" class="wb_page_anchor" id="page_1_anchor"></a><div id="wb_element_instance5" class="wb_element"><div></div></div><div id="wb_element_instance6" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">100</h5>
</div><div id="wb_element_instance7" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 3px dashed #00ffc8;"></div></div><div id="wb_element_instance8" class="wb_element" style=" line-height: normal;"><h2 class="wb-stl-heading2" style="text-align: center;">Days</h2></div><div id="wb_element_instance9" class="wb_element"><div></div></div><div id="wb_element_instance10" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">100</h5>
</div><div id="wb_element_instance11" class="wb_element" style=" line-height: normal;"><h2 class="wb-stl-heading2" style="text-align: center;">Hours</h2></div><div id="wb_element_instance12" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 3px dashed #00ffc8;"></div></div><div id="wb_element_instance13" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 10px solid #00d68f;"></div></div><div id="wb_element_instance14" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 10px solid #00d68f;"></div></div><div id="wb_element_instance15" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 10px solid #00d68f;"></div></div><div id="wb_element_instance16" class="wb_element" style=" line-height: normal;"><h3 class="wb-stl-heading3"><font color="#ffffff">A new generation of something. Something you wanna know about something you don't know.</font></h3>
</div><div id="wb_element_instance17" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">Our site is coming soon</h5></div></div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 240px;">
	
<div id="wb_element_instance1" class="wb_element"><div class="wb-stl-footer" style="white-space: nowrap;">I <i class="icon-wb-logo"></i><a href="http://zyro.com/" target="_blank" title="Zyro - Website Builder">Zyro</a></div></div><div id="wb_element_instance2" class="wb_element"><iframe width="200" height="140" style="width: 200px; height: 140px;" scrolling="no" allowTransparency="true" src="https://www.facebook.com/plugins/like.php?locale=en_US&amp;href=http%3A%2F%2Fwww.facebook.com%2Fjenusits&amp;layout=standard&amp;show_faces=true&amp;width=200&amp;height=140&amp;action=like&amp;colorscheme=dark" frameborder="0"></iframe></div><div id="wb_element_instance18" class="wb_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Contact us</h2></div><div id="wb_element_instance19" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-highlight"><strong>Address:</strong> </span></p>

<p class="wb-stl-normal"><font color="#ffffff" face="Trebuchet MS, sans-serif"><span style="font-size: 16px; line-height: normal;">Not available.</span></font></p>
</div><div id="wb_element_instance20" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-highlight">Phone: </span></p>

<p><span class="wb-stl-highlight">+639091312379</span></p>

<p><span class="wb-stl-highlight">E-mail: </span></p>

<p><span class="wb-stl-highlight">abelardomanangan@gmail.com</span></p>
</div><div id="wb_element_instance22" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(160);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>
