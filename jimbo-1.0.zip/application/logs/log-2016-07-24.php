<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-24 20:34:31 --> 404 Page Not Found: HomeController/index
ERROR - 2016-07-24 20:34:32 --> 404 Page Not Found: HomeController/index
