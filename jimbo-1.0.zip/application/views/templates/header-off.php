<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $pageTitle ;?></title>
		<link rel="icon" type="image/png" href="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/J_Church_logo.svg/2000px-J_Church_logo.svg.png">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	</head>

	<body>

	<header class="header">

		<div >

			<ul>
				<li></li>
				<li><a href="dashboard.php">Dashboard</a></li>
				<li>Systems</li>
				<li><a href="logout.php">Logout</a></li>
			</ul>

		</div>

	</header>

	<section class="section">